/**
 * cPanel / Phusion Passenger entry point for farm-server.
 *
 * Passenger (cPanel "Setup Node.js App") spawns ONE startup file and hooks the
 * FIRST http.Server.listen() call in that process ("reverse port binding",
 * auto-install mode) — any second listen() in the same process throws
 * "http.Server.listen() was called more than once". So this entry:
 *
 *   1. spawns the domains app (all domain modules) as a CHILD process with
 *      Passenger's hook env stripped, so it binds a real 127.0.0.1:4099 like
 *      on Render (merged-process mode, see render.yaml),
 *   2. builds the API gateway in-process via createApiApp() and performs the
 *      single listen() below — Passenger binds it to its own socket; outside
 *      Passenger (local runs) it binds PORT normally.
 *
 * cPanel setup:
 *   - Application root:  <dir containing this repo>/farm-server
 *   - Application startup file:  cpanel.js
 *   - Node.js version: 20 or 22 (NestJS 11 requires >= 20)
 *   - Put .env in the farm-server directory (gitignored — never deployed).
 *     Required vars include DATABASE_URL, JWT secrets, and the merged-mode
 *     *_SERVICE_URL values (set automatically here if unset).
 *   - Deploy/build steps: see .cpanel.yml at the repository root.
 */
const { loadEnv } = require('@farm/env');
loadEnv();

const path = require('path');
const net = require('net');
const { spawn } = require('child_process');
const express = require('express');

const DOMAIN_PORT = Number(process.env.DOMAINS_SERVICE_PORT) || 4099;
const DOMAIN_BASE = `http://127.0.0.1:${DOMAIN_PORT}`;
const BOOTSTRAP_TIMEOUT_MS = Number(process.env.BOOTSTRAP_TIMEOUT_MS) || 120000;
const PORT = Number(process.env.PORT || process.env.API_SERVICE_PORT) || 3000;

// The gateway proxy reads these when GatewayProxyService is constructed
// (app-server/src/modules/api/proxy/http-proxy.service.ts). Point every service
// at the domains child unless the environment already overrides them.
// (Same merged-process wiring as render.yaml and server.js.)
for (const key of [
  'AUTH', 'FARM', 'CROP', 'LIVESTOCK', 'POULTRY', 'FINANCE', 'HR',
  'NOTIFICATION', 'ORGANIZATION', 'PLATFORM', 'REPORTING',
]) {
  if (!process.env[`${key}_SERVICE_URL`]) {
    process.env[`${key}_SERVICE_URL`] = DOMAIN_BASE;
  }
}
if (!process.env.DOMAINS_SERVICE_PORT) {
  process.env.DOMAINS_SERVICE_PORT = String(DOMAIN_PORT);
}

/** Resolve once the domains child accepts connections on DOMAIN_PORT. */
function waitForPort(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve, reject) => {
    const attempt = () => {
      const socket = net.connect({ port, host: '127.0.0.1' }, () => {
        socket.end();
        resolve();
      });
      socket.on('error', () => {
        socket.destroy();
        if (Date.now() > deadline) {
          reject(new Error(`domains app did not start listening on ${port} within ${timeoutMs}ms`));
        } else {
          setTimeout(attempt, 250);
        }
      });
    };
    attempt();
  });
}

let domainsChild = null;
let shuttingDown = false;

function startDomains() {
  const env = { ...process.env };
  // Passenger injects its reverse-port-binding hook through the environment;
  // the domains child must bind a REAL TCP port (127.0.0.1:4099) for the
  // gateway's axios proxy, so strip anything Passenger-related from the child.
  delete env.NODE_OPTIONS;
  for (const key of Object.keys(env)) {
    if (/^PASSENGER/i.test(key)) delete env[key];
  }

  const child = spawn(
    process.execPath,
    [path.join(__dirname, 'app-server', 'dist', 'microservices', 'domains.main.js')],
    { cwd: __dirname, env, stdio: 'inherit' },
  );
  child.on('error', (err) => {
    console.error(`[cpanel.js] failed to start domains child: ${err.message}`);
    if (!shuttingDown) process.exit(1);
  });
  child.on('exit', (code, signal) => {
    console.error(`[cpanel.js] domains child exited (code=${code} signal=${signal})`);
    // The gateway is useless without its downstream — exit so Passenger/cPanel
    // restarts the whole app (mirrors scripts/start-prod.js behaviour).
    if (!shuttingDown) process.exit(code && code !== 0 ? code : 1);
  });
  return child;
}

let readyPromise = null;

function bootstrap() {
  if (!readyPromise) {
    readyPromise = (async () => {
      console.log('[cpanel.js] starting domains service (child process)...');
      domainsChild = startDomains();
      await waitForPort(DOMAIN_PORT, BOOTSTRAP_TIMEOUT_MS);
      console.log(`[cpanel.js] domains service listening on ${DOMAIN_PORT}`);

      console.log('[cpanel.js] booting API gateway (in-process)...');
      const { createApiApp } = require('./app-server/dist/microservices/api.main.js');
      const gateway = await createApiApp();
      console.log('[cpanel.js] gateway ready');
      return gateway.getHttpAdapter().getInstance();
    })();
    // Allow a retry on the next request if this boot attempt failed.
    readyPromise.catch(() => {
      readyPromise = null;
    });
  }
  return readyPromise;
}

function shutdown(code) {
  if (shuttingDown) return;
  shuttingDown = true;
  if (domainsChild) {
    try {
      domainsChild.kill('SIGTERM');
    } catch (e) {}
  }
  setTimeout(() => process.exit(code), 200);
}

process.on('SIGTERM', () => shutdown(0));
process.on('SIGINT', () => shutdown(0));

const app = express();

// Hold each request until bootstrap finishes (the first request after a cold
// start pays for the Nest init; later requests reuse the warm process).
app.use((req, res, next) => {
  bootstrap().then((gateway) => gateway(req, res), next);
});

// JSON error responses instead of Express' default HTML error page.
app.use((err, req, res, _next) => {
  console.error('[cpanel.js] request failed:', err);
  if (!res.headersSent) {
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
});

// THE one and only listen() in this process — do not add another one, or
// Passenger's auto-install mode will throw "listen() was called more than once".
app.listen(PORT, () => {
  console.log(`[cpanel.js] HTTP server listening on port ${PORT}`);
  // Warm up in the background so early requests (held by the gate above)
  // resolve as soon as the gateway is ready.
  bootstrap();
});

